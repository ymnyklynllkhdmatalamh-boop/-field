import { useEffect, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowLeft, ArrowUpRight, BadgeCheck, Building2, Check, ChevronDown, Clock3,
  Droplets, Fan, Flame, Home as HomeIcon, Leaf, Menu, MessageCircle, Phone,
  ShieldCheck, Sparkles, Star, Waves, X, Wrench, X as XIcon,
} from 'lucide-react';
import { Route, Switch, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();
const PHONE = '0599631840';
const PHONE_DISPLAY = '059 963 1840';
const WA_LINK = `https://wa.me/966${PHONE.slice(1)}?text=${encodeURIComponent('السلام عليكم، أود حجز خدمة تنظيف في جدة')}`;

function TikTokPixel() {
  useEffect(() => {
    const w = window as typeof window & { ttq?: { load: (id: string) => void; page: () => void } };
    if (!w.ttq) {
      const ttq = {
        load: (id: string) => { document.documentElement.dataset.tiktokPixel = id; },
        page: () => { document.documentElement.dataset.tiktokPage = 'view'; },
      };
      w.ttq = ttq;
      ttq.load('DACJAERC77U47UVQFLD0');
      ttq.page();
    } else {
      w.ttq.page();
    }
  }, []);
  return null;
}

function SectionKicker({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return (
    <div className={`mb-4 flex items-center gap-3 text-[11px] font-bold tracking-[.18em] ${light ? 'text-teal-100/70' : 'text-primary'}`}>
      <span className={`h-px w-8 ${light ? 'bg-accent' : 'bg-accent'}`} />
      <span>{children}</span>
    </div>
  );
}

function Logo({ inverse = false }: { inverse?: boolean }) {
  return (
    <a href="#top" className="flex items-center gap-3" data-testid="link-logo">
      <span className={`grid h-11 w-11 place-items-center rounded-2xl ${inverse ? 'bg-accent text-foreground' : 'bg-primary text-primary-foreground'}`}>
        <Droplets size={23} strokeWidth={2.2} />
      </span>
      <span className={`leading-none ${inverse ? 'text-background' : 'text-foreground'}`}>
        <strong className="block text-[17px] font-extrabold tracking-tight">نظافة جدة</strong>
        <small className={`mt-1 block text-[9px] font-medium tracking-[.2em] ${inverse ? 'text-teal-100/65' : 'text-muted-foreground'}`}>نظافة تُرى وتُحس</small>
      </span>
    </a>
  );
}

function CallButton({ compact = false, dark = false }: { compact?: boolean; dark?: boolean }) {
  return (
    <a
      href={`tel:${PHONE}`}
      data-testid="link-call"
      className={`inline-flex items-center justify-center gap-2 rounded-full font-bold transition-all hover:-translate-y-0.5 ${compact ? 'px-4 py-2 text-xs' : 'px-5 py-3.5 text-sm'} ${dark ? 'bg-background text-primary shadow-lg shadow-black/10' : 'bg-primary text-primary-foreground shadow-lg shadow-primary/20'}`}
    >
      <Phone size={compact ? 15 : 17} />
      <span dir="ltr">{PHONE_DISPLAY}</span>
    </a>
  );
}

function WhatsAppButton({ compact = false }: { compact?: boolean }) {
  return (
    <a
      href={WA_LINK}
      target="_blank"
      rel="noreferrer"
      data-testid="link-whatsapp"
      className={`inline-flex items-center justify-center gap-2 rounded-full bg-accent font-bold text-foreground transition-all hover:-translate-y-0.5 hover:brightness-105 ${compact ? 'px-4 py-2 text-xs' : 'px-5 py-3.5 text-sm'}`}
    >
      <MessageCircle size={compact ? 15 : 18} />
      <span>واتساب</span>
    </a>
  );
}

function Home() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [showBooking, setShowBooking] = useState(false);
  const [lightbox, setLightbox] = useState<{ src: string; alt: string } | null>(null);

  useEffect(() => {
    document.title = 'نظافة جدة | تنظيف عميق يليق ببيتك';
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'ar';
  }, []);

  const services = [
    { icon: HomeIcon, title: 'تنظيف الفلل والبيوت', text: 'تنظيف عميق لكل زاوية، من الأرضيات حتى أعلى الأسقف، بفريق يعرف تفاصيل البيت السعودي.' },
    { icon: Building2, title: 'المباني والشقق', text: 'خطط مرنة للمجمعات والمكاتب والشقق، بنتيجة ثابتة ومواعيد تلتزم بها.' },
    { icon: Sparkles, title: 'الكنب والمفروشات', text: 'بخار احترافي ينعش الأقمشة ويزيل البقع والروائح من دون إتلاف النسيج.' },
    { icon: Waves, title: 'السجاد والستائر', text: 'غسيل وعناية دقيقة تعيد اللون والملمس وتترك المكان أخف وأنظف.' },
    { icon: Wrench, title: 'بعد التشطيب', text: 'نزيل غبار البناء وآثاره من الأرضيات والزجاج والخزائن قبل التسليم.' },
    { icon: Fan, title: 'المكيفات والخزانات', text: 'تنظيف وصيانة دورية للمكيفات والخزانات لبيئة أنقى وأداء أفضل.' },
  ];

  const faqs = [
    ['هل تصلون إلى جميع أحياء جدة؟', 'نعم، نخدم أحياء جدة بالكامل من شمالها إلى جنوبها، وننسق الموعد حسب موقعك واحتياج المكان.'],
    ['كم يستغرق التنظيف؟', 'يختلف الوقت حسب المساحة ونوع الخدمة. بعد معرفة التفاصيل نعطيك تقديراً واضحاً قبل الحجز، ونضمن سرعة التنفيذ دون استعجال على حساب النتيجة.'],
    ['هل مواد التنظيف آمنة؟', 'نستخدم مواد مختارة بعناية، آمنة على الأسطح والأقمشة ومناسبة للبيوت التي فيها أطفال أو حيوانات أليفة.'],
    ['هل يوجد ضمان على الخدمة؟', 'نعم، تضمن لك نظافة جدة جودة الخدمة لمدة 48 ساعة. إذا لاحظت ملاحظة، نعود لمعالجتها دون تعقيد.'],
    ['كيف أحجز؟', 'اتصل بنا مباشرة أو أرسل رسالة واتساب. سيجيبك فريق التنسيق ويحدد الموعد والتفاصيل في دقائق.'],
  ];

  return (
    <div id="top" className="noise min-h-[100dvh] overflow-x-hidden bg-background text-foreground" dir="rtl">
      <TikTokPixel />
      <div className="bg-sidebar px-5 py-2 text-center text-[10px] font-medium text-teal-50/80 sm:text-xs">
        <span className="text-accent">عرض هذا الأسبوع</span>
        <span className="mx-2 text-teal-100/40">•</span>
        خصم خاص عند حجز تنظيف الفيلا أو البيت بالكامل
        <a href="#contact" className="mr-3 font-bold text-background underline decoration-accent underline-offset-4" data-testid="link-offer">اعرف التفاصيل</a>
      </div>

      <header className="absolute inset-x-0 top-9 z-30">
        <div className="container-wide flex items-center justify-between py-5">
          <Logo inverse />
          <nav className="hidden items-center gap-8 text-[12px] font-medium text-teal-50/80 lg:flex">
            <a href="#services" className="transition-colors hover:text-background" data-testid="link-services">خدماتنا</a>
            <a href="#story" className="transition-colors hover:text-background" data-testid="link-story">النتيجة قبل الكلام</a>
            <a href="#contracts" className="transition-colors hover:text-background" data-testid="link-contracts">للمنشآت</a>
            <a href="#faq" className="transition-colors hover:text-background" data-testid="link-faq">الأسئلة الشائعة</a>
          </nav>
          <div className="hidden items-center gap-2 sm:flex">
            <a href={WA_LINK} target="_blank" rel="noreferrer" className="rounded-full border border-teal-100/25 px-4 py-2 text-xs font-bold text-background transition hover:bg-background/10" data-testid="link-header-whatsapp">راسلنا الآن</a>
            <CallButton compact dark />
          </div>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="grid h-10 w-10 place-items-center rounded-xl border border-teal-100/25 text-background lg:hidden" aria-label={mobileOpen ? 'إغلاق القائمة' : 'فتح القائمة'} data-testid="button-mobile-menu">
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        {mobileOpen && (
          <div className="container-wide rounded-2xl bg-sidebar px-5 py-5 shadow-xl lg:hidden">
            <nav className="grid gap-4 text-sm font-semibold text-background">
              {['services', 'story', 'contracts', 'faq'].map((id, i) => <a key={id} href={`#${id}`} onClick={() => setMobileOpen(false)} data-testid={`link-mobile-${id}`}>{['خدماتنا', 'النتيجة قبل الكلام', 'للمنشآت', 'الأسئلة الشائعة'][i]}</a>)}
            </nav>
            <div className="mt-5 flex gap-2 border-t border-teal-100/15 pt-4"><CallButton compact dark /><WhatsAppButton compact /></div>
          </div>
        )}
      </header>

      <main>
        <section className="relative overflow-hidden bg-sidebar text-background">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_13%_78%,rgba(26,190,175,.16),transparent_34%),linear-gradient(110deg,rgba(19,66,75,.96),rgba(17,69,77,.88))]" />
          <div className="absolute -left-28 top-32 h-96 w-96 rounded-full border border-teal-100/10" />
          <div className="absolute -left-16 top-48 h-64 w-64 rounded-full border border-teal-100/10" />
          <div className="container-wide relative grid min-h-[730px] items-end gap-10 pb-14 pt-44 lg:grid-cols-[.86fr_1.14fr] lg:items-center lg:pb-20 lg:pt-36">
            <div className="reveal relative z-10 max-w-[650px]">
              <SectionKicker light>خدمة تنظيف محلية في جدة</SectionKicker>
              <h1 className="max-w-[680px] text-balance text-[40px] font-extrabold leading-[1.35] tracking-[-.04em] sm:text-[56px] lg:text-[72px]">
                بيتك يستحق<br /><span className="text-accent">نظافة تُرى.</span>
              </h1>
              <p className="reveal reveal-delay-1 mt-6 max-w-[520px] text-[15px] leading-8 text-teal-50/75 sm:text-lg">
                تنظيف عميق للفلل والبيوت والمنشآت في جدة، بفريق مدرّب ومواد آمنة ونتيجة تلاحظها من أول دخول.
              </p>
              <div className="reveal reveal-delay-2 mt-8 flex flex-wrap gap-3">
                <button onClick={() => setShowBooking(true)} className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-4 text-sm font-extrabold text-foreground shadow-xl shadow-black/15 transition hover:-translate-y-1" data-testid="button-book-hero">
                  احجز موعدك الآن <ArrowLeft size={17} />
                </button>
                <a href={WA_LINK} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-teal-100/25 px-5 py-4 text-sm font-bold text-background transition hover:border-accent hover:text-accent" data-testid="link-whatsapp-hero">
                  <MessageCircle size={18} /> تحدث مع المنسق
                </a>
              </div>
              <div className="reveal reveal-delay-3 mt-10 flex flex-wrap items-center gap-x-8 gap-y-4 text-[11px] text-teal-50/70">
                <span className="flex items-center gap-2"><BadgeCheck size={17} className="text-accent" /> ضمان جودة 48 ساعة</span>
                <span className="flex items-center gap-2"><ShieldCheck size={17} className="text-accent" /> مواد آمنة ومعتمدة</span>
              </div>
            </div>
            <div className="relative h-[340px] overflow-hidden rounded-[2rem] border border-teal-100/15 bg-teal-900/40 shadow-2xl shadow-black/25 sm:h-[430px] lg:h-[510px]">
               <button type="button" onClick={() => setLightbox({ src: '/jeddah-cleaning-hero.png', alt: 'فريق نظافة جدة ينظف غرفة معيشة' })} className="absolute inset-0 h-full w-full cursor-zoom-in text-right" aria-label="تكبير صورة فريق التنظيف" data-testid="button-zoom-hero-image">
                 <img src="/jeddah-cleaning-hero.png" alt="فريق نظافة جدة ينظف غرفة معيشة" className="h-full w-full object-cover opacity-90 mix-blend-screen" />
               </button>
              <div className="absolute inset-0 bg-gradient-to-t from-sidebar/80 via-transparent to-sidebar/10" />
              <div className="float-soft absolute bottom-6 right-6 max-w-[220px] rounded-2xl border border-background/20 bg-sidebar/85 p-4 backdrop-blur-md">
                <div className="mb-3 flex items-center gap-2"><span className="grid h-7 w-7 place-items-center rounded-full bg-accent text-foreground"><Sparkles size={14} /></span><span className="text-[11px] font-bold">تفاصيل تفرق</span></div>
                <p className="text-[11px] leading-6 text-teal-50/70">نصل إلى الأماكن التي لا يراها أحد، لتشعر بالفرق في كل نفس.</p>
              </div>
              <div className="absolute left-5 top-5 rounded-full bg-background/90 px-3 py-2 text-[10px] font-extrabold text-primary shadow-lg">جدة — نخدمك أينما كنت</div>
            </div>
          </div>
          <div className="container-wide relative -mb-1 flex items-center justify-between border-t border-teal-100/15 py-5 text-[10px] text-teal-50/50">
            <span>تنظيف بضمير مهني</span><span className="hidden sm:block">وقتكم مهم — نلتزم بالموعد</span><span>059 963 1840</span>
          </div>
        </section>

        <section className="relative bg-background py-20 sm:py-28">
          <div className="container-wide grid gap-10 lg:grid-cols-[.75fr_1.25fr]">
            <div>
              <SectionKicker>لماذا نظافة جدة؟</SectionKicker>
              <h2 className="text-balance text-3xl font-extrabold leading-[1.55] tracking-tight sm:text-5xl">الفرق ليس في اللمعة فقط.<br /><span className="text-primary">الفرق في راحة بالك.</span></h2>
              <p className="mt-6 max-w-md text-sm leading-8 text-muted-foreground">نحن فريق سعودي بإدارة محلية، نفهم طبيعة بيوت جدة وحرارة جوّها ورطوبتها. نأتي بخطة واضحة، أدوات حديثة، ونغادر المكان أفضل مما وجدناه.</p>
              <a href="#contact" className="mt-7 inline-flex items-center gap-2 text-sm font-extrabold text-primary underline decoration-accent decoration-2 underline-offset-8" data-testid="link-about-cta">اطلب تقييم المكان <ArrowLeft size={16} /></a>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {[
                { icon: Clock3, title: 'في الموعد', text: 'نصل في الوقت المتفق عليه ونبدأ مباشرة.' },
                { icon: Leaf, title: 'مواد آمنة', text: 'اختيارات لطيفة على البيت، قوية على الأوساخ.' },
                { icon: Wrench, title: 'معدات حديثة', text: 'بخار وشفط احترافي لنتيجة أعمق.' },
                { icon: BadgeCheck, title: 'ضمان 48 ساعة', text: 'رضاك جزء من الخدمة، وليس جملة في الإعلان.' },
              ].map(({ icon: Icon, title, text }, i) => {
                return <div key={String(title)} className={`group rounded-3xl border border-border bg-card p-6 transition duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5 ${i === 1 ? 'sm:translate-y-8' : ''}`} data-testid={`card-trust-${i}`}>
                  <Icon className="mb-8 text-primary transition-transform group-hover:scale-110" size={27} strokeWidth={1.7} />
                  <h3 className="text-sm font-extrabold">{title}</h3><p className="mt-2 text-xs leading-6 text-muted-foreground">{text}</p>
                </div>;
              })}
            </div>
          </div>
        </section>

        <section id="services" className="bg-secondary/55 py-20 sm:py-28">
          <div className="container-wide">
            <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
              <div><SectionKicker>خدماتنا</SectionKicker><h2 className="text-3xl font-extrabold tracking-tight sm:text-5xl">من أول المدخل<br />إلى آخر تفصيلة.</h2></div>
              <p className="max-w-sm text-sm leading-7 text-muted-foreground">اختر ما يحتاجه مكانك، ونبني لك الخدمة المناسبة — مرة واحدة أو بجدول منتظم.</p>
            </div>
            <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {services.map(({ icon: Icon, title, text }, i) => (
                <button key={title} onClick={() => setShowBooking(true)} className={`group relative min-h-[225px] overflow-hidden rounded-3xl border border-border bg-card p-6 text-right transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl hover:shadow-primary/10 ${i === 0 ? 'bg-primary text-primary-foreground' : ''}`} data-testid={`button-service-${i}`}>
                  <div className={`flex items-start justify-between ${i === 0 ? 'text-accent' : 'text-primary'}`}><Icon size={29} strokeWidth={1.5} /><ArrowUpRight size={19} className="opacity-40 transition group-hover:opacity-100" /></div>
                  <div className="absolute -left-6 -top-7 text-[150px] font-black leading-none opacity-[.035]">{String(i + 1).padStart(2, '0')}</div>
                  <h3 className="mt-12 text-base font-extrabold">{title}</h3><p className={`mt-3 text-xs leading-6 ${i === 0 ? 'text-primary-foreground/75' : 'text-muted-foreground'}`}>{text}</p>
                </button>
              ))}
            </div>
            <div className="mt-6 flex flex-col items-center justify-between gap-5 rounded-3xl bg-sidebar px-7 py-6 text-background sm:flex-row">
              <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-accent text-foreground"><Flame size={19} /></span><span className="text-sm font-bold">لم تجد الخدمة التي تبحث عنها؟<small className="mt-1 block text-[11px] font-normal text-teal-50/60">ننسق لك حلاً يناسب المكان والميزانية.</small></span></div>
              <button onClick={() => setShowBooking(true)} className="rounded-full border border-teal-100/25 px-5 py-3 text-xs font-bold transition hover:border-accent hover:text-accent" data-testid="button-custom-service">اسألنا عن احتياجك <ArrowLeft className="mr-2 inline" size={14} /></button>
            </div>
          </div>
        </section>

        <section id="story" className="overflow-hidden bg-background py-20 sm:py-28">
          <div className="container-wide">
            <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_.9fr]">
              <div className="relative order-2 h-[410px] sm:h-[540px] lg:order-1">
                 <button type="button" onClick={() => setLightbox({ src: '/jeddah-cleaning-detail.png', alt: 'تنظيف بالبخار لقطعة أثاث' })} className="absolute inset-y-0 right-0 w-[82%] cursor-zoom-in overflow-hidden rounded-[2rem] text-right" aria-label="تكبير صورة التنظيف بالبخار" data-testid="button-zoom-detail-image"><img src="/jeddah-cleaning-detail.png" alt="تنظيف بالبخار لقطعة أثاث" className="h-full w-full object-cover" /></button>
                 <button type="button" onClick={() => setLightbox({ src: '/jeddah-cleaning-hero.png', alt: 'نتيجة التنظيف في غرفة معيشة' })} className="absolute bottom-8 left-0 w-[54%] cursor-zoom-in overflow-hidden rounded-[1.5rem] border-[7px] border-background text-right shadow-2xl" aria-label="تكبير صورة نتيجة التنظيف" data-testid="button-zoom-result-image"><img src="/jeddah-cleaning-hero.png" alt="نتيجة التنظيف في غرفة معيشة" className="h-48 w-full object-cover object-left sm:h-64" /></button>
                <div className="absolute right-5 top-5 rounded-2xl bg-accent px-4 py-3 shadow-xl"><span className="block text-2xl font-extrabold">48</span><span className="text-[9px] font-bold">ساعة ضمان</span></div>
              </div>
              <div className="order-1 lg:order-2"><SectionKicker>النتيجة قبل الكلام</SectionKicker><h2 className="text-balance text-3xl font-extrabold leading-[1.55] sm:text-5xl">عندما يختفي الغبار،<br /><span className="text-primary">يظهر بيتك.</span></h2><p className="mt-6 text-sm leading-8 text-muted-foreground">لا نغطي المشكلة برائحة عطر. نعالجها من مصدرها. من بخار الكنب إلى زوايا المطابخ وآثار التشطيب — نعمل بهدوء، نراجع التفاصيل، ثم نترك لك مساحة تشعر أنها لك من جديد.</p>
                <div className="mt-8 grid grid-cols-2 gap-5 border-t border-border pt-7"><div><strong className="text-2xl font-extrabold text-primary">+١,٢٠٠</strong><small className="mt-1 block text-[10px] text-muted-foreground">مكان نظفناه في جدة</small></div><div><strong className="text-2xl font-extrabold text-primary">٤٫٩ / ٥</strong><small className="mt-1 block text-[10px] text-muted-foreground">متوسط تقييم العملاء</small></div></div>
              </div>
            </div>
          </div>
        </section>

        <section id="contracts" className="bg-primary py-20 text-primary-foreground sm:py-24">
          <div className="container-wide grid gap-10 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
            <div><SectionKicker light>حلول للمنشآت</SectionKicker><h2 className="text-balance text-3xl font-extrabold leading-[1.55] sm:text-5xl">نظافة مستمرة،<br /><span className="text-accent">بدون ما تشغل بالك.</span></h2><p className="mt-5 max-w-md text-sm leading-8 text-primary-foreground/70">عقود شهرية مرنة للعيادات والمجمعات الطبية والمدارس والمكاتب والمطاعم والمساجد. فريق ثابت، جدول واضح، وتقارير بعد كل زيارة.</p><button onClick={() => setShowBooking(true)} className="mt-7 inline-flex items-center gap-2 rounded-full bg-background px-5 py-3.5 text-sm font-extrabold text-primary transition hover:-translate-y-1" data-testid="button-contract">اطلب عرض منشأتك <ArrowLeft size={16} /></button></div>
            <div className="grid gap-3 sm:grid-cols-2">
              {['المجمعات الطبية', 'المدارس والروضات', 'المكاتب والشركات', 'المطاعم والمقاهي', 'المساجد والمرافق', 'الواجهات الزجاجية'].map((item, i) => <div key={item} className="flex items-center gap-4 rounded-2xl border border-primary-foreground/15 bg-primary-foreground/10 p-4 transition hover:bg-primary-foreground/15" data-testid={`card-contract-${i}`}><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-accent text-foreground"><Check size={17} /></span><span className="text-xs font-bold">{item}</span></div>)}
            </div>
          </div>
        </section>

        <section className="bg-secondary/50 py-20 sm:py-28">
          <div className="container-wide"><div className="flex items-end justify-between gap-5"><div><SectionKicker>قالوا بعد التجربة</SectionKicker><h2 className="text-3xl font-extrabold sm:text-5xl">نترك أثراً طيباً.</h2></div><div className="hidden items-center gap-1 text-accent sm:flex"><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /><Star size={16} fill="currentColor" /></div></div>
            <div className="mt-12 grid gap-4 lg:grid-cols-[1.15fr_.85fr_.85fr]">
              <blockquote className="relative rounded-3xl bg-sidebar p-7 text-background sm:p-9"><span className="absolute left-7 top-4 text-7xl font-serif text-accent/40">“</span><div className="relative z-10"><div className="mb-7 flex gap-1 text-accent"><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /><Star size={15} fill="currentColor" /></div><p className="text-base font-medium leading-8">النتيجة فاقت توقعاتي. الفريق حضر في الموعد، اشتغل باحترافية وترك الفيلا برائحة نظافة خفيفة وليست مزعجة. أكيد ستكونون خياري كل مرة.</p><footer className="mt-8 flex items-center gap-3 border-t border-teal-100/15 pt-5"><span className="grid h-9 w-9 place-items-center rounded-full bg-accent text-xs font-extrabold text-foreground">ن</span><span><strong className="block text-xs">نوف الغامدي</strong><small className="text-[10px] text-teal-50/50">حي الشاطئ، جدة</small></span></footer></div></blockquote>
              {[['أ. خالد الحربي', 'تنظيف مكتب', 'التزام ممتاز بالتفاصيل والوقت. تعامل راقٍ ونتيجة نظيفة فعلاً.'], ['سارة الزهراني', 'تنظيف كنب', 'رجع لون الكنب كأنه جديد. تعامل الفريق كان لطيفاً وسريعاً.']].map(([name, role, text], i) => <blockquote key={name} className={`rounded-3xl border border-border bg-card p-6 ${i === 1 ? 'lg:translate-y-8' : ''}`}><div className="mb-6 flex gap-1 text-accent"><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /><Star size={13} fill="currentColor" /></div><p className="text-sm leading-7 text-muted-foreground">“{text}”</p><footer className="mt-7 border-t border-border pt-5"><strong className="block text-xs">{name}</strong><small className="mt-1 block text-[10px] text-muted-foreground">{role} — جدة</small></footer></blockquote>)}
            </div>
          </div>
        </section>

        <section id="faq" className="bg-background py-20 sm:py-28">
          <div className="container-wide grid gap-12 lg:grid-cols-[.72fr_1.28fr]">
            <div><SectionKicker>أسئلة في بالكم</SectionKicker><h2 className="text-3xl font-extrabold leading-[1.55] sm:text-5xl">بكل وضوح،<br /><span className="text-primary">قبل أن نبدأ.</span></h2><p className="mt-5 max-w-sm text-sm leading-7 text-muted-foreground">إذا لم تجد إجابتك، فريقنا جاهز على الواتساب. لا نحب التعقيد، ولا نطلب منك تفاصيل أكثر من اللازم.</p><a href={WA_LINK} target="_blank" rel="noreferrer" className="mt-7 inline-flex items-center gap-2 text-sm font-extrabold text-primary" data-testid="link-faq-whatsapp">اسأل المنسق مباشرة <MessageCircle size={17} /></a></div>
            <div className="border-t border-border">{faqs.map(([question, answer], i) => <div key={question} className="border-b border-border"><button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="flex w-full items-center justify-between gap-4 py-6 text-right text-sm font-extrabold" aria-expanded={openFaq === i} data-testid={`button-faq-${i}`}><span>{question}</span><ChevronDown size={18} className={`shrink-0 text-primary transition-transform ${openFaq === i ? 'rotate-180' : ''}`} /></button>{openFaq === i && <p className="pb-6 pl-9 text-xs leading-7 text-muted-foreground">{answer}</p>}</div>)}</div>
          </div>
        </section>

        <section id="contact" className="relative overflow-hidden bg-sidebar py-20 text-background sm:py-28">
          <div className="absolute -left-40 -top-40 h-[500px] w-[500px] rounded-full border border-teal-100/10" /><div className="absolute -left-24 -top-24 h-[350px] w-[350px] rounded-full border border-teal-100/10" />
          <div className="container-wide relative grid gap-12 lg:grid-cols-[1.1fr_.9fr] lg:items-center">
            <div><SectionKicker light>خطوتك التالية</SectionKicker><h2 className="text-balance text-4xl font-extrabold leading-[1.45] tracking-tight sm:text-6xl">خلّ النظافة<br /><span className="text-accent">علينا.</span></h2><p className="mt-6 max-w-md text-sm leading-8 text-teal-50/70">احجز موعدك الآن، وسيتواصل معك منسق الخدمة لتحديد التفاصيل والوقت المناسب في جدة.</p><div className="mt-8 flex flex-wrap gap-3"><CallButton dark /><WhatsAppButton /></div><div className="mt-8 flex items-center gap-3 text-xs text-teal-50/55"><ShieldCheck size={17} className="text-accent" /> استجابة سريعة — خدمة داخل جدة — ضمان 48 ساعة</div></div>
            <div className="rounded-[2rem] border border-teal-100/15 bg-teal-900/40 p-7 backdrop-blur-sm sm:p-9"><div className="mb-7 flex items-center justify-between"><div><p className="text-xs font-bold text-accent">اتصل بنا مباشرة</p><h3 className="mt-2 text-2xl font-extrabold" dir="ltr">{PHONE_DISPLAY}</h3></div><div className="grid h-14 w-14 place-items-center rounded-2xl bg-accent text-foreground"><Phone size={24} /></div></div><div className="space-y-3 text-xs text-teal-50/65"><p className="flex items-center gap-3"><Check size={15} className="text-accent" /> تغطية جميع أحياء جدة</p><p className="flex items-center gap-3"><Check size={15} className="text-accent" /> مواعيد صباحية ومسائية</p><p className="flex items-center gap-3"><Check size={15} className="text-accent" /> فريق محترف ومواد آمنة</p></div><a href={`tel:${PHONE}`} className="mt-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-background py-4 text-sm font-extrabold text-primary transition hover:bg-accent" data-testid="link-final-call">اتصل الآن — نرد عليك <ArrowLeft size={16} /></a></div>
          </div>
        </section>
      </main>

      <footer className="bg-[hsl(194_49%_15%)] py-7 text-teal-50/50"><div className="container-wide flex flex-col items-center justify-between gap-5 text-[10px] sm:flex-row"><Logo inverse /><div className="flex items-center gap-5"><a href={WA_LINK} target="_blank" rel="noreferrer" className="transition hover:text-background" data-testid="link-footer-whatsapp">واتساب</a><a href="https://www.tiktok.com" target="_blank" rel="noreferrer" className="transition hover:text-background" data-testid="link-footer-tiktok">تيك توك</a><a href={`tel:${PHONE}`} className="transition hover:text-background" data-testid="link-footer-phone" dir="ltr">{PHONE_DISPLAY}</a></div><span>© {new Date().getFullYear()} نظافة جدة</span></div></footer>

       <div className="fixed bottom-5 left-5 z-40 flex flex-col gap-3" aria-label="تواصل سريع">
         <a href={WA_LINK} target="_blank" rel="noreferrer" className="grid h-14 w-14 place-items-center rounded-full bg-accent text-foreground shadow-xl shadow-black/20 transition hover:scale-105" aria-label="تواصل عبر واتساب" data-testid="button-floating-whatsapp"><MessageCircle size={25} /></a>
         <a href={`tel:${PHONE}`} className="grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-xl shadow-black/20 transition hover:scale-105" aria-label="اتصال هاتفي" data-testid="button-floating-call"><Phone size={23} /></a>
       </div>

       {lightbox && <div className="fixed inset-0 z-[60] grid place-items-center bg-sidebar/85 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="عرض الصورة" onClick={() => setLightbox(null)}><div className="relative max-h-[90vh] max-w-5xl overflow-hidden rounded-3xl border border-background/20 bg-sidebar shadow-2xl" onClick={(event) => event.stopPropagation()}><button type="button" onClick={() => setLightbox(null)} className="absolute left-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-background/90 text-foreground shadow-lg" aria-label="إغلاق الصورة" data-testid="button-close-lightbox"><XIcon size={18} /></button><img src={lightbox.src} alt={lightbox.alt} className="max-h-[85vh] w-auto max-w-full object-contain" /></div></div>}
       {showBooking && <div className="fixed inset-0 z-50 grid place-items-center bg-sidebar/70 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="حجز موعد"><div className="relative w-full max-w-md rounded-[2rem] bg-background p-7 shadow-2xl sm:p-9"><button onClick={() => setShowBooking(false)} className="absolute left-5 top-5 grid h-9 w-9 place-items-center rounded-full bg-secondary text-foreground" aria-label="إغلاق" data-testid="button-close-booking"><XIcon size={17} /></button><span className="grid h-12 w-12 place-items-center rounded-2xl bg-accent text-foreground"><Sparkles size={22} /></span><h3 className="mt-5 text-2xl font-extrabold">نبدأ من احتياجك.</h3><p className="mt-3 text-sm leading-7 text-muted-foreground">تواصل معنا الآن، وسيسألك المنسق عن المكان ونوع التنظيف ثم يقترح لك الموعد الأنسب.</p><div className="mt-7 grid gap-3"><a href={`tel:${PHONE}`} className="flex items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-sm font-extrabold text-primary-foreground" data-testid="link-modal-call"><Phone size={18} /> اتصل بـ {PHONE_DISPLAY}</a><a href={WA_LINK} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-2xl bg-accent py-4 text-sm font-extrabold text-foreground" data-testid="link-modal-whatsapp"><MessageCircle size={18} /> احجز عبر واتساب</a></div><p className="mt-5 text-center text-[10px] text-muted-foreground">نخدم جميع أحياء جدة ونرد عليك بأسرع وقت</p></div></div>}
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <ErrorBoundary><Router /></ErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;